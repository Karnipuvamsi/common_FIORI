/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/core/library"],function(){"use strict";sap.ui.getCore().initLibrary({name:"sap.btp.ui5lib",version:"1.0.0",dependencies:["sap.ui.core"],noLibraryCSS:true,types:[],interfaces:[],controls:["sap.btp.ui5lib.controls.Reuse"],elements:[]});return sap.btp.ui5lib},false);
//# sourceMappingURL=library.js.map