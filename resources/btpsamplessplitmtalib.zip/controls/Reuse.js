/*!
 * ${copyright}
 */
sap.ui.define(["./../library","sap/ui/core/Control","./ReuseRenderer"],function(e,t,r){"use strict";var s=t.extend("btp.samples.split.mta.lib.controls.Reuse",{metadata:{library:"btp.samples.split.mta.lib",properties:{text:{type:"string",defaultValue:null}},events:{press:{}}},renderer:r});return s},true);
//# sourceMappingURL=Reuse.js.map