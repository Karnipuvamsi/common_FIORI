/*!
 * ${copyright}
 */
sap.ui.define([],function(){"use strict";var e={};e.render=function(e,t){e.write("<div");e.writeControlData(t);e.addClass("sapRULTReuse");e.writeClasses();e.write(">");e.write(sap.ui.getCore().getLibraryResourceBundle("btp.samples.split.mta.lib").getText("ANY_TEXT"));e.writeEscaped(t.getText());e.write("</div>")};return e},true);
//# sourceMappingURL=ReuseRenderer.js.map