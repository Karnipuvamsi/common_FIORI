/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/core/library"],function(){"use strict";sap.ui.getCore().initLibrary({name:"btp.samples.split.mta.lib",version:"1.0.0",dependencies:["sap.ui.core"],noLibraryCSS:true,types:[],interfaces:[],controls:["btp.samples.split.mta.lib.controls.Reuse"],elements:[]});return btp.samples.split.mta.lib},false);
//# sourceMappingURL=library.js.map